from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the pre-trained model and feature columns
model = joblib.load('credit_approval_model.pkl')
model_columns = joblib.load('model_columns.pkl')

# Define unique values for dropdowns
unique_values = {
    'NAME_INCOME_TYPE': ['Working', 'Commercial associate', 'Pensioner', 'State servant', 'Student'],
    'NAME_EDUCATION_TYPE': ['Secondary / secondary special', 'Higher education', 'Incomplete higher', 'Lower secondary', 'Academic degree'],
    'NAME_FAMILY_STATUS': ['Married', 'Single / not married', 'Civil marriage', 'Separated', 'Widow'],
    'NAME_HOUSING_TYPE': ['House / apartment', 'With parents', 'Municipal apartment', 'Rented apartment', 'Office apartment', 'Co-op apartment'],
    'OCCUPATION_TYPE': ['Laborers', 'Core staff', 'Sales staff', 'Managers', 'Drivers', 'High skill tech staff', 'Accountants', 'Medicine staff', 'Cooking staff', 'Security staff', 'Cleaning staff', 'Private service staff', 'Low-skill Laborers', 'Secretaries', 'Waiters/barmen staff', 'HR staff', 'IT staff', 'Realty agents']
}

def predict(data):
    # Ensure all required columns are present
    for column in model_columns:
        if column not in data:
            data[column] = 0
    data = pd.DataFrame([data])
    
    # Ensure columns are in the correct order
    data = data.reindex(columns=model_columns, fill_value=0)
    
    # Make prediction
    prediction = model.predict(data)
    return prediction[0]

@app.route('/')
def index():
    return render_template('index.html', unique_values=unique_values)

@app.route('/predict', methods=['POST'])
def predict_route():
    data = request.form.to_dict()

    # Convert numeric fields to appropriate types
    numeric_fields = ['CNT_CHILDREN', 'AMT_INCOME_TOTAL', 'CNT_FAM_MEMBERS', 'AGE_YEARS', 'YEARS_EMPLOYED']
    for field in numeric_fields:
        try:
            data[field] = float(data.get(field, 0))
        except ValueError:
            data[field] = 0

    
    if data['AMT_INCOME_TOTAL'] <= 0 or data['AGE_YEARS']<=0 or data['YEARS_EMPLOYED'] <= 0:
        return render_template('result.html', result="Rejected")

    # Convert categorical fields to the expected format
    categorical_fields = ['NAME_INCOME_TYPE', 'NAME_EDUCATION_TYPE', 'NAME_FAMILY_STATUS', 'NAME_HOUSING_TYPE', 'OCCUPATION_TYPE']
    for field in categorical_fields:
        if data.get(field) not in unique_values[field]:
            data[field] = 'Unknown'  # or handle the unknown value appropriately
    
    # Make prediction
    prediction = predict(data)
    result = "Approved" if prediction == 0 else "Rejected"
    return render_template('result.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)


