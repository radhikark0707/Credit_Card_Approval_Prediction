# Import necessary libraries
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load datasets
application_record = pd.read_csv('application_record.csv')
credit_record = pd.read_csv('credit_record.csv')

# Merge datasets
merged_data = pd.merge(application_record, credit_record, on='ID', how='inner')

# Create target column
merged_data['TARGET'] = merged_data['STATUS'].apply(lambda x: 1 if x in ['1', '2', '3', '4'] else 0)
merged_data.loc[merged_data['STATUS'].isin(['C', 'X']), 'TARGET'] = 0

# Handle missing values
merged_data['OCCUPATION_TYPE'] = merged_data['OCCUPATION_TYPE'].fillna('Unknown')

# Convert 'DAYS_BIRTH' and 'DAYS_EMPLOYED' to years and drop original columns
merged_data['AGE_YEARS'] = merged_data['DAYS_BIRTH'] / -365.25
merged_data['YEARS_EMPLOYED'] = merged_data['DAYS_EMPLOYED'] / -365.25
merged_data.drop(['DAYS_BIRTH', 'DAYS_EMPLOYED'], axis=1, inplace=True)

# Round 'AGE_YEARS' and 'YEARS_EMPLOYED'
merged_data['AGE_YEARS'] = merged_data['AGE_YEARS'].round()
merged_data['YEARS_EMPLOYED'] = merged_data['YEARS_EMPLOYED'].round()

# Handle YEARS_EMPLOYED anomalies
condition = merged_data['YEARS_EMPLOYED'].apply(lambda x: str(x).startswith('-999'))
merged_data.loc[condition, 'YEARS_EMPLOYED'] = np.nan
median_value = merged_data['YEARS_EMPLOYED'].median()
merged_data['YEARS_EMPLOYED'] = merged_data['YEARS_EMPLOYED'].fillna(median_value)

# Outlier treatment for 'AMT_INCOME_TOTAL'
Q1 = merged_data['AMT_INCOME_TOTAL'].quantile(0.25)
Q3 = merged_data['AMT_INCOME_TOTAL'].quantile(0.75)
IQR = Q3 - Q1
upper_bound = Q3 + 1.5 * IQR
merged_data['AMT_INCOME_TOTAL'] = merged_data['AMT_INCOME_TOTAL'].apply(lambda x: min(x, upper_bound))

# Handle 'CNT_CHILDREN' and 'CNT_FAM_MEMBERS' outliers
merged_data['CNT_CHILDREN'] = merged_data['CNT_CHILDREN'].clip(upper=5)
merged_data['CNT_FAM_MEMBERS'] = merged_data['CNT_FAM_MEMBERS'].clip(upper=8)

# Drop unnecessary columns
columns_to_drop = ['ID', 'FLAG_MOBIL', 'FLAG_WORK_PHONE', 'FLAG_PHONE', 'FLAG_EMAIL', 'STATUS', 'MONTHS_BALANCE']
print("Columns in DataFrame:", merged_data.columns)
merged_data.drop(columns=[col for col in columns_to_drop if col in merged_data.columns], axis=1, inplace=True)

# Encoding categorical variables
merged_data['CODE_GENDER'] = merged_data['CODE_GENDER'].map({'F': 0, 'M': 1})
merged_data['FLAG_OWN_CAR'] = merged_data['FLAG_OWN_CAR'].map({'N': 0, 'Y': 1})
merged_data['FLAG_OWN_REALTY'] = merged_data['FLAG_OWN_REALTY'].map({'N': 0, 'Y': 1})

# One-hot encoding for remaining categorical variables
categorical_columns = ['NAME_INCOME_TYPE', 'NAME_EDUCATION_TYPE', 'NAME_FAMILY_STATUS', 'NAME_HOUSING_TYPE', 'OCCUPATION_TYPE']
merged_data = pd.get_dummies(merged_data, columns=categorical_columns, drop_first=True)

# Ensure all data is numeric
print("Data Types of Columns:")
print(merged_data.dtypes)

# Reduce the dataset size by taking a 10% sample for experimentation
merged_data_sample = merged_data.sample(frac=0.1, random_state=42)

# Define X and y for model training
X = merged_data_sample.drop('TARGET', axis=1)
y = merged_data_sample['TARGET']

# Save the model columns for the Flask app
model_columns = X.columns
joblib.dump(model_columns, 'model_columns.pkl')

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train a RandomForestClassifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Test the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Model Accuracy: {accuracy * 100:.2f}%')

# Save the trained model to a file
joblib.dump(model, 'credit_approval_model.pkl')
print("Model saved as credit_approval_model.pkl")
